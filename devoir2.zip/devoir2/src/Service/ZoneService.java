package Service;

import java.util.ArrayList;
import java.util.List;

import Enteties.Zone;

public class ZoneService {
    private List<Zone> zones;

    public ZoneService() {
        zones = new ArrayList<>();
    }

    public void createZone(String nom) {
        Zone zone = new Zone(nom);
        zones.add(zone);
    }

    public List<Zone> listZones() {
        return zones;
    }
}