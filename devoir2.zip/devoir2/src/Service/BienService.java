package Service;

import java.util.ArrayList;
import java.util.List;

import Enteties.Bien;
import Enteties.Zone;

public class BienService {
    private List<Bien> biens;

    public BienService() {
        biens = new ArrayList<>();
    }

    public void addBien(String nom, Zone zone) {
        Bien bien = new Bien(nom, zone);
        biens.add(bien);
    }

    public List<Bien> listBiens() {
        return biens;
    }
}
