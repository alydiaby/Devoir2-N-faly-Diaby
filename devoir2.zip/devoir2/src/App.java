

import java.util.Scanner;

import Enteties.Bien;
import Enteties.Zone;
import Service.BienService;
import Service.ZoneService;

public class App {
    private ZoneService zoneService;
    private BienService bienService;

    public App() {
        zoneService = new ZoneService();
        bienService = new BienService();
    

    
        Scanner scanner = new Scanner(System.in);
        int choix = 0;

        do {
            System.out.println("Menu:");
            System.out.println("1. Créer une zone");
            System.out.println("2. Lister les zones");
            System.out.println("3. Ajouter un bien ");
            System.out.println("4. Lister les biens en affichant le nom de la zone");
            System.out.println("5. Quitter");
            System.out.print("Choix: ");
            choix = scanner.nextInt();

            switch (choix) {
                case 1:
                
                    createZone(scanner);
                    break;
                case 2:
                    listZones();
                    break;
                case 3:
                    addBien(scanner);
                    break;
                case 4:
                    listBiens();
                    break;
                case 5:
                    System.out.println("Au revoir !");
                    break;
                default:
                    System.out.println("Choix invalide. Veuillez réessayer.");
            }
        } while (choix != 5); }
    

    

    private void listZones() {
        System.out.println("Liste des zones:");
        for (Zone zone : zoneService.listZones()) {
            System.out.println(zone.getNom());
        }
        System.out.println();
    }

    private void addBien(Scanner scanner) {
        System.out.print("Nom du bien: ");
        String nom = scanner.next();
        System.out.print("Nom de la zone: ");
        String zoneNom = scanner.next();

        boolean zoneExists = false;
        for (Zone zone : zoneService.listZones()) {
            if (zone.getNom().equals(zoneNom)) {
                bienService.addBien(nom, zone);
                zoneExists = true;
                break;
            }
        }

        if (zoneExists) {
            System.out.println("Bien ajouté avec succès !");
        } else {
            System.out.println("La zone spécifiée n'existe pas.");
        }

        System.out.println();
    }

    private void listBiens() {
        System.out.println("Liste des biens:");
        for (Bien bien : bienService.listBiens()) {
            System.out.println(bien.getNom() + " - " + bien.getZone().getNom());
        }
        System.out.println();
    }

   
}
