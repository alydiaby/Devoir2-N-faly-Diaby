package Enteties;

import java.sql.Date;

public class Bien {
    private int id;
    private String nom;
    private String refecence;
    private String description;
    private Double prix;
    private Date dateCreation;


   
}