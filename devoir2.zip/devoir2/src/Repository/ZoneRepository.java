package Repository;

import java.util.ArrayList;
import java.util.List;

import Enteties.Zone;

public class ZoneRepository {
    private List<Zone> zones;

    public ZoneRepository() {
        zones = new ArrayList<>();
    }

    public void createZone(Zone zone) {
        zones.add(zone);
    }

    public List<Zone> getAllZones() {
        return zones;
    }
}


