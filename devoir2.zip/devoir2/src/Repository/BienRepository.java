package Repository;

import java.util.ArrayList;
import java.util.List;

import Enteties.Bien;

public class BienRepository {
    private List<Bien> biens;

    public BienRepository() {
        biens = new ArrayList<>();
    }

    public void addBien(Bien bien) {
        biens.add(bien);
    }

    public List<Bien> getAllBiens() {
        return biens;
    }
}
